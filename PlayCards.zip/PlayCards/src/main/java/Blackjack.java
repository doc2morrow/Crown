import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

public class Blackjack {

    final static int HTTP_STATUS_OK = 200;

    static List<String> winners = new ArrayList<>();
    static int numberOfPlayers = 2;

    public static void main(String[] args) throws IOException {

        URL url;
        String apiUrl = " https://deckofcardsapi.com/";
        HttpURLConnection connection;

        url = new URL(apiUrl);
        connection = (HttpURLConnection) url.openConnection();

        int responseCode = connection.getResponseCode();
        if (responseCode != HTTP_STATUS_OK) {
            System.out.println("Page did not load correctly");
            return;
        }

        String getNewDeck = apiUrl + "/api/deck/new/";
        url = new URL(getNewDeck);
        connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("GET");


        String shuffleDeck = apiUrl + "/api/deck/new/shuffle/?deck_count=6/";
        url = new URL(shuffleDeck);
        connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("GET");

        for(int x = 0; x<numberOfPlayers; x++) {
            try {
                String drawCards = apiUrl + "https://deckofcardsapi.com/api/deck/<<deck_id>>/draw/?count=3";
                url = new URL(drawCards);
                connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");

                // Read the response
                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;

                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                reader.close();

                int playerIdx = x+1;
                if (isBlackJack(response.toString())) {
                    winners.add("player " + playerIdx);

                }

                // Close the connection
                connection.disconnect();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        System.out.println("Blackjack Winners: \n" +winners);
    }


    private static int parseResponse(String response) {
        // Create ObjectMapper
        ObjectMapper objectMapper = new ObjectMapper();

        // Parse JSON string
        JsonNode jsonNode = null;
        try {
            jsonNode = objectMapper.readTree(response);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }

        // Access the array of items
        JsonNode itemsNode = jsonNode.get("items");

        int value = 0;
        for (JsonNode itemNode : itemsNode) {
            value += itemNode.get("value").asInt();
        }

        return value;
    }

    private static boolean isBlackJack(String response) {
        return parseResponse(response) == 21;
    }
}







