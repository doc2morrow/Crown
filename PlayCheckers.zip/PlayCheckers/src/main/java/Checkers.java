import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class Checkers {

       public static void main(String[] args) {
      // Set the path to your chromedriver executable
        System.setProperty("webdriver.chrome.driver", "C:\\Projects\\PlayCheckers\\chromedriver.exe");

      // Create a new instance of the Chrome driver
        WebDriver driver = (WebDriver) new ChromeDriver();

        // Navigate to checkers website
        driver.get("https://www.gamesforthebrain.com/game/checkers/");

       // Confirm wesite has loaded using the message and header fiels
        WebElement header = driver.findElement(By.cssSelector("body > div.all > div.page > h1"));
        String headerText = header.getText();


        WebElement messageTextBox = driver.findElement(By.id("#message"));
        String messageText = messageTextBox.getText();

        if(!headerText.trim().equals("Checkers") || !messageText.trim().equals("Select an orange piece to move.")) {
            System.out.println("Checker did not load properly");
            return;
        }



        WebElement checker;
        WebElement target;
        int maxMoves=5;
        String[] checkerPositions = {"space42","space22","space31","space62","space12"};
        String[] targetPositions = {"space33","space13","space13","space53","space33"};

        checker = driver.findElement(By.name(checkerPositions[0]));
        checker.click();
        ;
        target = driver.findElement(By.name(targetPositions[0]));
        target.click();


        for(int i = 1; i<maxMoves; i++) {
            WebElement wait = new WebDriverWait(driver, Duration.ofSeconds(2)).until(ExpectedConditions.visibilityOfElementLocated(By.id("#message")));
            if (messageTextBox.getText().trim().equals("Make a move.")) {

                checker = driver.findElement(By.name(checkerPositions[i]));
                checker.click();
                ;
                target = driver.findElement(By.name(targetPositions[i]));
                target.click();
            }
        }

         WebElement restart = driver.findElement(By.cssSelector(" body > div.all > div.page > div.content > div.gameWrapper > p.footnote > a:nth-child(1)"))   ;
        restart.click();

        driver.quit();
    }
}

